#version 120
/*
 CrystalClear Shaders — final.fsh
 Last pass: saturation/contrast tweak, a filmic tonemap curve (Hejl/Burgess-
 Dawson approximation), and a soft vignette. Writes directly to the screen,
 so no DRAWBUFFERS directive is needed here.
*/
#define EXPOSURE 0.6 // [0.35 0.45 0.55 0.6 0.65 0.75 0.85]

uniform sampler2D colortex0;
varying vec2 texcoord;

vec3 tonemapFilmic(vec3 c) {
    vec3 x = max(vec3(0.0), c - 0.004);
    return (x * (6.2 * x + 0.5)) / (x * (6.2 * x + 1.7) + 0.06);
}

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;

    color = tonemapFilmic(color * EXPOSURE);

    // Mild desaturation-toward-neutral rather than a brightness-boosting
    // saturation push (V2's version pushed already-bright pixels brighter).
    float luma = dot(color, vec3(0.2126, 0.7152, 0.0722));
    color = mix(vec3(luma), color, 1.04);

    // Genuine darkening curve: gamma > 1 pulls midtones/highlights down
    // without crushing shadows to black the way a flat multiply would.
    color = pow(clamp(color, 0.0, 1.0), vec3(1.25));

    vec2 uv = texcoord - 0.5;
    float vignette = 1.0 - dot(uv, uv) * 0.6;
    color *= vignette;

    gl_FragColor = vec4(color, 1.0);
}
