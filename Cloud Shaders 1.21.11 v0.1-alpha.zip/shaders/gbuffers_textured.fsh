#version 120
uniform sampler2D gtexture;
uniform vec3 fogColor;
varying vec2 texcoord;
varying vec4 vertColor;
varying float viewDist;

const float FOG_DENSITY = 0.0018; // gentler than terrain fog; avoids washing out the sky/GUI

void main() {
    vec4 col = texture2D(gtexture, texcoord) * vertColor;
    float fogFactor = clamp(1.0 - exp(-viewDist * FOG_DENSITY), 0.0, 1.0);
    col.rgb = mix(col.rgb, fogColor, fogFactor * col.a);
    gl_FragColor = col;
}
