#version 120
uniform sampler2D gtexture;
uniform sampler2D lightmap;
uniform vec3 shadowLightPosition;
uniform vec3 fogColor;
uniform vec4 entityColor; // hit-flash tint (white, animated alpha) supplied by vanilla
uniform float alphaTestRef;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertColor;
varying vec3 normal;
varying float viewDist;

const float FOG_DENSITY = 0.0025;

void main() {
    vec4 albedo = texture2D(gtexture, texcoord) * vertColor;
    if (albedo.a < alphaTestRef) discard;

    vec3 n = normalize(normal);
    float NdotL = max(dot(n, normalize(shadowLightPosition)), 0.0);
    vec3 lightmapColor = texture2D(lightmap, lmcoord).rgb * 0.68;

    vec3 totalLight = clamp(lightmapColor + vec3(NdotL * 0.2), 0.0, 1.0);
    vec3 lit = albedo.rgb * totalLight;
    lit = mix(lit, entityColor.rgb, entityColor.a); // hit-flash overlay

    float fogFactor = clamp(1.0 - exp(-viewDist * FOG_DENSITY), 0.0, 1.0);
    vec3 finalColor = mix(lit, fogColor, fogFactor);

    gl_FragColor = vec4(finalColor, albedo.a);
}
