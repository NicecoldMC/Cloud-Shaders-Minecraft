#version 120
/*
 CrystalClear Shaders — gbuffers_terrain.fsh
 Lights terrain using the vanilla lightmap + a directional sun/moon term,
 darkens fragments inside the shadow map, and applies a custom exponential
 distance fog blended toward the sky/fog color.
*/

uniform sampler2D gtexture;
uniform sampler2D lightmap;
uniform sampler2D shadowtex0;
uniform vec3 shadowLightPosition; // direction toward sun/moon, in eye space
uniform vec3 fogColor;
uniform float alphaTestRef;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertColor;
varying vec3 normal;
varying vec4 shadowPos;
varying float viewDist;

const float FOG_DENSITY = 0.0025; // artistic distance fog curve, tune to taste

float sampleShadow() {
    // Outside the shadow map's coverage: treat as fully lit rather than
    // guessing, to avoid dark artifacts at the render-distance edge.
    if (shadowPos.x < 0.0 || shadowPos.x > 1.0 ||
        shadowPos.y < 0.0 || shadowPos.y > 1.0 ||
        shadowPos.z < 0.0 || shadowPos.z > 1.0) {
        return 1.0;
    }

    const float bias = 0.0015;
    float occluderDepth = texture2D(shadowtex0, shadowPos.xy).r;
    return (shadowPos.z - bias > occluderDepth) ? 0.35 : 1.0;
}

void main() {
    vec4 albedo = texture2D(gtexture, texcoord) * vertColor;
    if (albedo.a < alphaTestRef) discard;

    vec3 n = normalize(normal);
    float NdotL = max(dot(n, normalize(shadowLightPosition)), 0.0);
    float shadow = sampleShadow();

    // Vanilla block/sky lightmap (torches, sky brightness at this time of day).
    // Scaled down noticeably — the raw lightmap texture reads very bright at
    // full daylight (more so if the in-game Brightness slider isn't set to
    // "Moody"; see README), so this needs a firmer cut than V2's 0.85.
    vec3 lightmapColor = texture2D(lightmap, lmcoord).rgb * 0.68;

    // Directional sun/moon term, gated by the shadow map. Combined total is
    // hard-clamped to 1.0 so nothing can go into the tonemapper already
    // overexposed.
    float directional = NdotL * shadow * 0.22;
    vec3 totalLight = clamp(lightmapColor + vec3(directional), 0.0, 1.0);
    vec3 lit = albedo.rgb * totalLight;

    // Custom exponential fog toward the sky/fog color, based on view distance.
    float fogFactor = 1.0 - exp(-viewDist * FOG_DENSITY);
    fogFactor = clamp(fogFactor, 0.0, 1.0);
    vec3 finalColor = mix(lit, fogColor, fogFactor);

    gl_FragColor = vec4(finalColor, albedo.a);
}
