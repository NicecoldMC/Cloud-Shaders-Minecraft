#version 120
// CrystalClear Shaders — gbuffers_entities.vsh
// Used for: mobs, players, item frames, armor stands, etc.
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertColor;
varying vec3 normal;
varying float viewDist;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vertColor = gl_Color;
    normal = gl_NormalMatrix * gl_Normal;
    viewDist = length((gl_ModelViewMatrix * gl_Vertex).xyz);
}
