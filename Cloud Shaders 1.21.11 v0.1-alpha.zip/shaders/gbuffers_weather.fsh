#version 120
uniform sampler2D gtexture;
varying vec2 texcoord;
varying vec4 vertColor;
void main() {
    vec4 col = texture2D(gtexture, texcoord) * vertColor;
    col.a *= 0.6; // softer rain/snow so it doesn't look like a wall of static
    gl_FragColor = col;
}
