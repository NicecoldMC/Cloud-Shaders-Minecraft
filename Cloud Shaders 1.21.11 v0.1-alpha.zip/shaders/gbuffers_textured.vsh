#version 120
// CrystalClear Shaders — gbuffers_textured.vsh
// Used for: sky, clouds, particles, GUI elements. Kept as a safe passthrough
// so these never look broken, with fog support for particles/clouds.
varying vec2 texcoord;
varying vec4 vertColor;
varying float viewDist;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vertColor = gl_Color;
    viewDist = length((gl_ModelViewMatrix * gl_Vertex).xyz);
}
