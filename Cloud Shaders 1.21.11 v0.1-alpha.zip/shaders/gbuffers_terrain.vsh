#version 120
/*
 CrystalClear Shaders — gbuffers_terrain.vsh
 Handles: all solid/cutout world terrain (blocks).
 Adds: waving grass & leaves, and computes shadow-space position for the
 fragment shader to sample the shadow map.
*/

#define WAVING_STRENGTH 0.8 // [0.0 0.4 0.8 1.2 1.6]

attribute vec4 mc_Entity;      // x = custom block ID from block.properties (-1 if unset)
attribute vec2 mc_midTexCoord; // center of this quad's texture, used to find the "top" vertex

uniform float frameTimeCounter;
uniform vec3 cameraPosition;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertColor;
varying vec3 normal;
varying vec4 shadowPos;
varying float viewDist;

// Pulls shadow detail toward the player so nearby shadows stay sharp while
// distant ones compress into the fixed-resolution shadow map.
vec3 distortShadowClipPos(vec3 pos) {
    float factor = length(pos.xy) + 0.10;
    pos.xy /= factor;
    return pos;
}

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vertColor = gl_Color;
    normal = gl_NormalMatrix * gl_Normal;

    vec4 position = gl_Vertex;
    int blockId = int(mc_Entity.x + 0.5);

    if (WAVING_STRENGTH > 0.0 && (blockId == 10001 || blockId == 10002)) {
        // Only the top vertex of the quad sways; the base stays anchored.
        // In Minecraft's texture space V increases downward, so the top
        // vertex has a smaller v than the quad's mid texcoord.
        float isTop = step(gl_MultiTexCoord0.y, mc_midTexCoord.y);

        vec3 worldPos = position.xyz + cameraPosition;
        float t = frameTimeCounter * 1.2;
        float phase = worldPos.x * 0.5 + worldPos.z * 0.5;

        float swayX = sin(t + phase) * 0.06 * WAVING_STRENGTH;
        float swayZ = cos(t * 0.8 + phase) * 0.06 * WAVING_STRENGTH;

        position.x += swayX * isTop;
        position.z += swayZ * isTop;
    }

    vec4 viewPos = gl_ModelViewMatrix * position;
    viewDist = length(viewPos.xyz);
    gl_Position = gl_ProjectionMatrix * viewPos;

    // Camera-relative "world" position (same convention Iris uses for the
    // shadow matrices), used to project into shadow-map space.
    vec4 worldSpacePos = gbufferModelViewInverse * viewPos;
    vec4 sPos = shadowProjection * (shadowModelView * worldSpacePos);
    sPos.xyz = distortShadowClipPos(sPos.xyz);
    // The shadow projection is orthographic (w == 1), so only xyz need the
    // [-1,1] -> [0,1] remap for texture/depth sampling; w is left untouched.
    shadowPos = vec4(sPos.xyz * 0.5 + 0.5, sPos.w);
}
