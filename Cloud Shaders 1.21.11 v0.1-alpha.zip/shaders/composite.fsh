#version 120
/*
 CrystalClear Shaders — composite.fsh
 Pass 1 of post-processing: passes the rendered scene through unchanged on
 colortex0, and extracts a bright-pass image on colortex1 for the blur step
 in composite1.fsh to turn into a soft bloom.
*/
uniform sampler2D colortex0;
varying vec2 texcoord;

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;

    float brightness = dot(color, vec3(0.2126, 0.7152, 0.0722));
    vec3 bright = color * smoothstep(1.0, 1.6, brightness);

    /* DRAWBUFFERS:01 */
    gl_FragData[0] = vec4(color, 1.0);
    gl_FragData[1] = vec4(bright, 1.0);
}
