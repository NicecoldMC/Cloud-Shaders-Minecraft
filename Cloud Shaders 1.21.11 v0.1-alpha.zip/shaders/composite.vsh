#version 120
// Standard full-screen-pass vertex shader, shared shape used by all
// composite/final programs.
varying vec2 texcoord;
void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}
