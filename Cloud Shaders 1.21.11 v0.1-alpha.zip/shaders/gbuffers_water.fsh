#version 120
/*
 CrystalClear Shaders V2 — gbuffers_water.fsh
 Uses the rippled wave normal for real diffuse shading + a sun-glint
 specular highlight, plus a richer (but capped, non-washed-out) fresnel
 edge and a deeper, more saturated tint than V1.
*/

uniform sampler2D gtexture;
uniform sampler2D lightmap;
uniform vec3 fogColor;
uniform vec3 shadowLightPosition;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertColor;
varying vec3 waveNormal;
varying vec3 viewDir;
varying float viewDist;

const vec3 WATER_DEEP  = vec3(0.02, 0.10, 0.16); // deep/shadowed water tint
const vec3 WATER_SHALLOW = vec3(0.10, 0.32, 0.36); // sunlit surface tint
const float FOG_DENSITY = 0.0025;

void main() {
    vec4 albedo = texture2D(gtexture, texcoord) * vertColor;

    vec3 n = normalize(waveNormal);
    vec3 lightDir = normalize(shadowLightPosition);
    vec3 view = normalize(viewDir);

    float NdotL = max(dot(n, lightDir), 0.0);
    float fresnel = pow(1.0 - clamp(dot(n, view), 0.0, 1.0), 4.0);

    // Sun glint: a tight specular highlight along the reflection vector.
    // Toned down from V2, which could blow out to near-white on calm water
    // facing the sun.
    vec3 reflectDir = reflect(-lightDir, n);
    float specAngle = max(dot(reflectDir, view), 0.0);
    float glint = pow(specAngle, 120.0) * 0.6;

    vec3 lightmapColor = texture2D(lightmap, lmcoord).rgb * 0.68;

    // Blend deep/shallow tint by how directly lit the wave facet is, so
    // troughs read a little darker/deeper than crests.
    vec3 waterColor = mix(WATER_DEEP, WATER_SHALLOW, NdotL);
    vec3 baseColor = mix(albedo.rgb, waterColor, 0.65) * lightmapColor;

    vec3 litColor = baseColor + vec3(glint) * lightmapColor;
    litColor = mix(litColor, litColor + vec3(0.3, 0.33, 0.33), fresnel * 0.15);
    litColor = clamp(litColor, 0.0, 1.0);

    float alpha = clamp(albedo.a * 0.75 + fresnel * 0.25 + glint * 0.3, 0.0, 1.0);

    float fogFactor = clamp(1.0 - exp(-viewDist * FOG_DENSITY), 0.0, 1.0);
    vec3 finalColor = mix(litColor, fogColor, fogFactor);

    gl_FragColor = vec4(finalColor, alpha);
}
