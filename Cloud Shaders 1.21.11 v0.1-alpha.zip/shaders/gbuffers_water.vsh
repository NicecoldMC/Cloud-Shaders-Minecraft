#version 120
/*
 CrystalClear Shaders V2 — gbuffers_water.vsh
 Displaces water with layered sine waves AND computes an analytic
 wave-perturbed normal (the derivative of the wave height field), so the
 surface actually catches light differently as it ripples instead of
 shading like a flat plane.
*/

uniform float frameTimeCounter;
uniform vec3 cameraPosition;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertColor;
varying vec3 waveNormal;
varying vec3 viewDir;
varying float viewDist;

const float WAVE_A_FREQ = 0.6;
const float WAVE_A_SPEED = 1.1;
const float WAVE_A_AMP = 0.035;

const float WAVE_B_FREQ = 0.4;
const float WAVE_B_SPEED = 0.8;
const float WAVE_B_AMP = 0.035;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vertColor = gl_Color;

    vec4 position = gl_Vertex;
    vec3 worldPos = position.xyz + cameraPosition;
    float t = frameTimeCounter;

    float phaseA = worldPos.x * WAVE_A_FREQ + t * WAVE_A_SPEED;
    float phaseB = worldPos.z * WAVE_B_FREQ - t * WAVE_B_SPEED;

    float wave = sin(phaseA) * WAVE_A_AMP + sin(phaseB) * WAVE_B_AMP;
    position.y += wave;

    // Analytic surface normal from the wave height field's slope:
    // dHeight/dx and dHeight/dz tilt the "up" normal accordingly.
    float dHdx = cos(phaseA) * WAVE_A_FREQ * WAVE_A_AMP;
    float dHdz = cos(phaseB) * WAVE_B_FREQ * WAVE_B_AMP;
    vec3 localWaveNormal = normalize(vec3(-dHdx, 1.0, -dHdz));
    waveNormal = normalize(gl_NormalMatrix * localWaveNormal);

    vec4 viewPos = gl_ModelViewMatrix * position;
    viewDir = normalize(-viewPos.xyz);
    viewDist = length(viewPos.xyz);

    gl_Position = gl_ProjectionMatrix * viewPos;
}
