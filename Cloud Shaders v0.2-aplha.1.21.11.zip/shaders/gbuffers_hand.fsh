#version 120
/*
 Vessel Shaders V10 — gbuffers_hand.fsh
 Held-item shader (this program itself is a V7 addition — before that,
 Iris fell back to a generic pass with no real lighting model at all,
 which was part of why held items looked uncontrolled-bright). V10 uses
 the same simple V5-style lighting formula as terrain/entities now use
 (no block-light cap or additive glow), per feedback that the cap/glow
 system made things look muted overall.
*/
#define NIGHT_DARKNESS 0.35 // [0.15 0.25 0.35 0.5 0.7]

uniform sampler2D gtexture;
uniform sampler2D lightmap;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform float alphaTestRef;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertColor;

void main() {
    vec4 albedo = texture2D(gtexture, texcoord) * vertColor;
    if (albedo.a < alphaTestRef) discard;

    float sunHeight = dot(normalize(sunPosition), normalize(upPosition));
    float dayFactor = clamp(sunHeight * 3.0 + 0.5, 0.0, 1.0);
    float ambientNightMul = mix(NIGHT_DARKNESS, 1.0, dayFactor);

    // Slightly higher base than world geometry (0.72 vs 0.68) so the held
    // item stays clearly legible in dim light.
    vec3 rawLightmap = texture2D(lightmap, lmcoord).rgb * 0.72;
    float torchStrength = clamp(lmcoord.x * 1.4, 0.0, 1.0);
    vec3 lightmapColor = rawLightmap * mix(ambientNightMul, 1.0, torchStrength);

    vec3 lit = albedo.rgb * clamp(lightmapColor, 0.0, 1.0);

    gl_FragColor = vec4(lit, albedo.a);
}
