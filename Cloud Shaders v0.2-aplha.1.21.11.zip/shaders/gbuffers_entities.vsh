#version 120
/*
 Vessel Shaders V4 — gbuffers_entities.vsh
 Used for: mobs, players, item frames, armor stands, etc.
 New in V4: computes shadow-space position so entities are properly
 darkened when standing in shade (V1-V3 lit entities with no shadow check).
*/

uniform vec3 cameraPosition;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertColor;
varying vec3 normal;
varying vec4 shadowPos;
varying float viewDist;

vec3 distortShadowClipPos(vec3 pos) {
    float factor = length(pos.xy) + 0.10;
    pos.xy /= factor;
    return pos;
}

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vertColor = gl_Color;
    normal = gl_NormalMatrix * gl_Normal;

    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    viewDist = length(viewPos.xyz);

    vec4 worldSpacePos = gbufferModelViewInverse * viewPos;
    vec4 sPos = shadowProjection * (shadowModelView * worldSpacePos);
    sPos.xyz = distortShadowClipPos(sPos.xyz);
    shadowPos = vec4(sPos.xyz * 0.5 + 0.5, sPos.w);
}
