#version 120
/*
 Vessel Shaders — shadow.vsh
 Runs once per frame from the sun/moon's point of view. Iris automatically
 substitutes the shadow projection/model-view matrices in place of
 gl_ProjectionMatrix / gl_ModelViewMatrix for this specific program.
*/
varying vec2 texcoord;
varying vec4 vertColor;

vec3 distortShadowClipPos(vec3 pos) {
    float factor = length(pos.xy) + 0.10;
    pos.xy /= factor;
    return pos;
}

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vertColor = gl_Color;

    vec4 pos = gl_ProjectionMatrix * (gl_ModelViewMatrix * gl_Vertex);
    pos.xyz = distortShadowClipPos(pos.xyz);
    gl_Position = pos;
}
