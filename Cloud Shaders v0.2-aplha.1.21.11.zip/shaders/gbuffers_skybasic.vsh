#version 120
/*
 Vessel Shaders V5 — gbuffers_skybasic.vsh
 Dedicated pass for untextured sky geometry: stars, the void plane, and the
 horizon/sky-gradient quads. Plain vertex-color passthrough, matching what
 gbuffers_basic already did as a fallback — made explicit here so the sky
 doesn't depend on fallback behavior.
*/
varying vec4 vertColor;
void main() {
    gl_Position = ftransform();
    vertColor = gl_Color;
}
