#version 120
// Vessel Shaders — gbuffers_basic.vsh
// Used for: block selection outline, debug wireframes, misc untextured geometry.
varying vec4 vertColor;
void main() {
    gl_Position = ftransform();
    vertColor = gl_Color;
}
