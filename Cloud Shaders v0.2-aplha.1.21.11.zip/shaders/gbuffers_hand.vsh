#version 120
/*
 Vessel Shaders V7 — gbuffers_hand.vsh
 New in V7: a dedicated program for the first-person held item/hand. V1-V6
 had no such program, so Iris fell back to a generic pass with no proper
 lighting model — which is why held items (especially glowing ones) could
 look uncontrolled-bright. This mirrors the entity lighting model (minus
 shadow sampling, which doesn't make sense for something locked to the
 camera) so held items are lit consistently with the rest of the world.
*/
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertColor;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vertColor = gl_Color;
}
