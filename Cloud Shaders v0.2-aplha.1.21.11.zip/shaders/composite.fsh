#version 120
/*
 Vessel Shaders V5 — composite.fsh
 Pass 1 of post-processing: extracts a bright-pass image for bloom, same as
 before. New in V5: real underwater fog. V1-V4 had no fog specific to being
 submerged, so being underwater looked almost identical to being on land —
 you could see far too clearly. This reconstructs each pixel's true
 distance from depth and fogs it toward a murky color, but ONLY when the
 camera's eye itself is in water (isEyeInWater), so looking at a lake from
 above the surface is unaffected.
*/
#define UNDERWATER_FOG_DENSITY 0.09 // [0.04 0.06 0.09 0.13 0.18]

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform int isEyeInWater;
varying vec2 texcoord;

const vec3 UNDERWATER_COLOR = vec3(0.02, 0.12, 0.16);

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;

    if (isEyeInWater == 1) {
        float depth = texture2D(depthtex0, texcoord).r;
        vec4 clipPos = vec4(texcoord * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
        vec4 viewPos = gbufferProjectionInverse * clipPos;
        viewPos /= viewPos.w;
        float dist = length(viewPos.xyz);

        float fog = clamp(1.0 - exp(-dist * UNDERWATER_FOG_DENSITY), 0.0, 1.0);
        color = mix(color, UNDERWATER_COLOR, fog);
    }

    float brightness = dot(color, vec3(0.2126, 0.7152, 0.0722));
    vec3 bright = color * smoothstep(1.0, 1.6, brightness);

    /* DRAWBUFFERS:01 */
    gl_FragData[0] = vec4(color, 1.0);
    gl_FragData[1] = vec4(bright, 1.0);
}
