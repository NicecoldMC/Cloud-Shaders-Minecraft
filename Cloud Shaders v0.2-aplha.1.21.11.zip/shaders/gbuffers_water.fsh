#version 120
/*
 Vessel Shaders V6 — gbuffers_water.fsh
 New in V6: the shading normal is computed per-fragment from a 3-octave
 procedural wave field sampled at this fragment's own world position, not
 interpolated from 4 coarse vertex normals. That's what fixes the faceted/
 blobby look — ripple detail and specular sparkle now vary smoothly across
 the whole lake instead of clumping per water block.
 Shadow sampling reduced from 9-tap to 4-tap PCF for performance (see
 README V6 notes).
*/

#define WATER_WAVE_STRENGTH 1.0 // [0.4 0.7 1.0 1.3 1.6]
#define SHADOW_SOFTNESS 1.0 // [0.0 1.0 2.0 3.0]
#define SHADOW_STRENGTH 0.4 // [0.15 0.25 0.4 0.55 0.7]
#define FOG_DENSITY 0.0025 // [0.0008 0.0015 0.0025 0.004 0.006]
#define NIGHT_DARKNESS 0.35 // [0.15 0.25 0.35 0.5 0.7]

uniform sampler2D gtexture;
uniform sampler2D lightmap;
uniform sampler2D shadowtex0;
uniform vec3 fogColor;
uniform vec3 shadowLightPosition;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform float frameTimeCounter;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertColor;
varying vec3 viewDir;
varying vec3 worldPos;
varying vec4 shadowPos;
varying float viewDist;

const vec3 WATER_DEEP  = vec3(0.02, 0.10, 0.16); // deep/shadowed water tint
const vec3 WATER_SHALLOW = vec3(0.10, 0.32, 0.36); // sunlit surface tint
const float SHADOW_TEXEL = 1.0 / 1024.0; // must match shaders.properties shadowMapResolution

// 4-tap PCF (was 9-tap in V1-V5) — a meaningful performance win since this
// runs on every visible water fragment, at the cost of very slightly
// coarser shadow edges on water specifically.
float sampleShadow(vec4 sp, float NdotL) {
    if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0 || sp.z < 0.0 || sp.z > 1.0) {
        return 1.0;
    }
    float bias = mix(0.0030, 0.0007, NdotL);
    float litSamples = 0.0;
    for (float x = -1.0; x <= 1.0; x += 2.0) {
        for (float y = -1.0; y <= 1.0; y += 2.0) {
            vec2 offset = vec2(x, y) * SHADOW_TEXEL * SHADOW_SOFTNESS * 0.75;
            float occluderDepth = texture2D(shadowtex0, sp.xy + offset).r;
            litSamples += (sp.z - bias > occluderDepth) ? 0.0 : 1.0;
        }
    }
    float litFraction = litSamples / 4.0;
    float minLight = clamp(1.0 - SHADOW_STRENGTH, 0.0, 1.0);
    return mix(minLight, 1.0, litFraction);
}

// Per-fragment procedural wave normal: three octaves of sine ripples at
// increasing frequency/decreasing amplitude, sampled at this exact pixel's
// world position rather than interpolated from the coarse mesh.
vec3 waveNormalAt(vec2 pos, float t) {
    float dHdx = 0.0;
    float dHdz = 0.0;

    dHdx += cos(pos.x * 0.6 + t * 1.1) * 0.6 * 0.035;
    dHdz += cos(pos.y * 0.4 - t * 0.8) * 0.4 * 0.035;

    dHdx += cos(pos.x * 1.7 + t * 1.8) * 1.7 * 0.012;
    dHdz += cos(pos.y * 1.3 - t * 1.4) * 1.3 * 0.012;

    dHdx += cos(pos.x * 3.8 + t * 2.6) * 3.8 * 0.004;
    dHdz += cos(pos.y * 3.1 - t * 2.1) * 3.1 * 0.004;

    dHdx *= WATER_WAVE_STRENGTH;
    dHdz *= WATER_WAVE_STRENGTH;

    return normalize(vec3(-dHdx, 1.0, -dHdz));
}

void main() {
    vec4 albedo = texture2D(gtexture, texcoord) * vertColor;

    vec3 n = waveNormalAt(worldPos.xz, frameTimeCounter);
    vec3 lightDir = normalize(shadowLightPosition);
    vec3 view = normalize(viewDir);

    float NdotL = max(dot(n, lightDir), 0.0);
    float shadow = sampleShadow(shadowPos, NdotL);
    float fresnel = pow(1.0 - clamp(dot(n, view), 0.0, 1.0), 4.0);

    float sunHeight = dot(normalize(sunPosition), normalize(upPosition));
    float dayFactor = clamp(sunHeight * 3.0 + 0.5, 0.0, 1.0);
    float ambientNightMul = mix(NIGHT_DARKNESS, 1.0, dayFactor);

    vec3 reflectDir = reflect(-lightDir, n);
    float specAngle = max(dot(reflectDir, view), 0.0);
    float glint = pow(specAngle, 120.0) * 0.6 * shadow * ambientNightMul;

    vec3 lightmapColor = texture2D(lightmap, lmcoord).rgb * 0.68 * ambientNightMul;

    vec3 waterColor = mix(WATER_DEEP, WATER_SHALLOW, NdotL * shadow);
    vec3 baseColor = mix(albedo.rgb, waterColor, 0.65) * lightmapColor;

    vec3 litColor = baseColor + vec3(glint) * lightmapColor;
    litColor = mix(litColor, litColor + vec3(0.3, 0.33, 0.33), fresnel * 0.15);
    litColor = clamp(litColor, 0.0, 1.0);

    float alpha = clamp(albedo.a * 0.75 + fresnel * 0.25 + glint * 0.3, 0.0, 1.0);

    float fogFactor = clamp(1.0 - exp(-viewDist * FOG_DENSITY), 0.0, 1.0);
    vec3 finalColor = mix(litColor, fogColor, fogFactor);

    gl_FragColor = vec4(finalColor, alpha);
}
