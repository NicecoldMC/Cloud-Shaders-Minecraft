#version 120
// Vessel Shaders — shadow.fsh
// Discards transparent fragments (leaves' cutout pixels, glass edges, etc.)
// so they don't cast solid black shadow blobs.
uniform sampler2D gtexture;
varying vec2 texcoord;
varying vec4 vertColor;

void main() {
    vec4 col = texture2D(gtexture, texcoord) * vertColor;
    if (col.a < 0.1) discard;
    gl_FragColor = col;
}
