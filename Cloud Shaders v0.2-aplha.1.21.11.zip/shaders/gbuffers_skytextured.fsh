#version 120
uniform sampler2D gtexture;
varying vec2 texcoord;
varying vec4 vertColor;

void main() {
    vec4 col = texture2D(gtexture, texcoord) * vertColor;
    if (col.a < 0.01) discard; // avoid writing near-transparent border pixels into the scene
    gl_FragColor = col;
}
