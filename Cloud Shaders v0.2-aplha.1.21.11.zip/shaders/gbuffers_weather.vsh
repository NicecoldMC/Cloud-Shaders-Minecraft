#version 120
// Vessel Shaders — gbuffers_weather.vsh
// Used for: rain and snow particle quads.
varying vec2 texcoord;
varying vec4 vertColor;
void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vertColor = gl_Color;
}
