#version 120
/*
 Vessel Shaders V10 — final.fsh
 Last pass: saturation/contrast tweak, a filmic tonemap curve (Hejl/Burgess-
 Dawson approximation), and a soft vignette. Writes directly to the screen,
 so no DRAWBUFFERS directive is needed here.
 V10: SATURATION raised from 1.04 (functionally a no-op) to 1.3 default —
 that near-flat value was a big part of the "dried out" look, on top of
 V7's block-light cap/glow (removed in this version — see
 gbuffers_terrain.fsh). EXPOSURE and the darkening gamma are unchanged.
*/
#define EXPOSURE 0.6 // [0.35 0.45 0.55 0.6 0.65 0.75 0.85]
#define SATURATION 1.3 // [1.0 1.15 1.3 1.45 1.6]
#define VIGNETTE_STRENGTH 0.6 // [0.0 0.3 0.6 0.9 1.2]

uniform sampler2D colortex0;
varying vec2 texcoord;

vec3 tonemapFilmic(vec3 c) {
    vec3 x = max(vec3(0.0), c - 0.004);
    return (x * (6.2 * x + 0.5)) / (x * (6.2 * x + 1.7) + 0.06);
}

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;

    color = tonemapFilmic(color * EXPOSURE);

    float luma = dot(color, vec3(0.2126, 0.7152, 0.0722));
    color = mix(vec3(luma), color, SATURATION);

    // Genuine darkening curve: gamma > 1 pulls midtones/highlights down
    // without crushing shadows to black the way a flat multiply would.
    color = pow(clamp(color, 0.0, 1.0), vec3(1.25));

    vec2 uv = texcoord - 0.5;
    float vignette = 1.0 - dot(uv, uv) * VIGNETTE_STRENGTH;
    color *= vignette;

    gl_FragColor = vec4(color, 1.0);
}
