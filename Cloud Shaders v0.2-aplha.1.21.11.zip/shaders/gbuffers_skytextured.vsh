#version 120
/*
 Vessel Shaders V5 — gbuffers_skytextured.vsh
 Dedicated pass for the sun and moon quads. New in V5: previously these had
 no dedicated program, so Iris fell back to gbuffers_textured — which
 applies distance fog meant for particles/GUI. Sky objects render at a huge
 fixed distance, so that fog math was incorrectly tinting/dimming the sun.
 This pass is a clean passthrough with no fog, so the sun/moon render as
 the vanilla texture intends (a bright disc that fades via its own alpha).
*/
varying vec2 texcoord;
varying vec4 vertColor;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vertColor = gl_Color;
}
