#version 120
/*
 Vessel Shaders V6 — composite1.fsh
 Pass 2: blurs the bright-pass buffer (colortex1) and adds it back onto the
 scene (colortex0) for a soft glow/bloom. Reduced from a 5x5 (25-tap) box
 blur to a 3x3 (9-tap) blur with wider spacing between samples — relies on
 bilinear texture filtering to fill the gaps, which keeps a similar-looking
 blur radius for roughly a third of the texture fetches.
*/
#define BLOOM_STRENGTH 0.2 // [0.0 0.1 0.2 0.35 0.5]

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform float viewWidth;
uniform float viewHeight;
varying vec2 texcoord;

void main() {
    vec2 texel = vec2(1.0 / viewWidth, 1.0 / viewHeight) * 3.2;
    vec3 blur = vec3(0.0);

    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            blur += texture2D(colortex1, texcoord + vec2(float(x), float(y)) * texel).rgb;
        }
    }
    blur /= 9.0;

    vec3 base = texture2D(colortex0, texcoord).rgb;
    vec3 result = base + blur * BLOOM_STRENGTH;

    /* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(result, 1.0);
}
