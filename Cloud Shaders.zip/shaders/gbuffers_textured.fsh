#version 120
/*
 Vessel Shaders V12 — gbuffers_textured.fsh
 Used for particles (block-break dust, critical hits, etc.). V12: this
 previously had no lighting model at all — just texture x vertex color —
 so particles always rendered at full raw brightness regardless of time
 of day, which is why they stood out as too bright at night once
 everything else got darkened. Now applies the same day/night ambient
 dimming as terrain/entities, with the same torch-light exception (a
 particle from breaking a block right next to a torch won't get
 needlessly darkened).
*/
#define NIGHT_DARKNESS 0.35 // [0.15 0.25 0.35 0.5 0.7]

uniform sampler2D gtexture;
uniform sampler2D lightmap;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform vec3 fogColor;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertColor;
varying float viewDist;

const float FOG_DENSITY = 0.0018; // gentler than terrain fog; avoids washing out particles at range

void main() {
    vec4 col = texture2D(gtexture, texcoord) * vertColor;

    float sunHeight = dot(normalize(sunPosition), normalize(upPosition));
    float dayFactor = clamp(sunHeight * 3.0 + 0.5, 0.0, 1.0);
    float ambientNightMul = mix(NIGHT_DARKNESS, 1.0, dayFactor);

    // Spare particles near a strong light source from the night dimming,
    // same as terrain/entities do.
    float torchStrength = clamp(lmcoord.x * 1.4, 0.0, 1.0);
    float particleNightMul = mix(ambientNightMul, 1.0, torchStrength);
    col.rgb *= particleNightMul;

    float fogFactor = clamp(1.0 - exp(-viewDist * FOG_DENSITY), 0.0, 1.0);
    col.rgb = mix(col.rgb, fogColor, fogFactor * col.a);
    gl_FragColor = col;
}
