#version 120
/*
 Vessel Shaders V14 — gbuffers_hand.fsh
 Held-item shader. Uses the same simple lighting formula as terrain/
 entities. V14: added the same minimum-lighting floor (MIN_LIGHT) so a
 held item in a fully dark spot isn't rendered pure black.
*/
#define NIGHT_DARKNESS 0.35 // [0.15 0.25 0.35 0.5 0.7]
#define MIN_LIGHT 0.05 // [0.0 0.03 0.05 0.08 0.12] floor so nothing goes fully pure black

uniform sampler2D gtexture;
uniform sampler2D lightmap;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform float alphaTestRef;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertColor;

void main() {
    vec4 albedo = texture2D(gtexture, texcoord) * vertColor;
    if (albedo.a < alphaTestRef) discard;

    float sunHeight = dot(normalize(sunPosition), normalize(upPosition));
    float dayFactor = clamp(sunHeight * 3.0 + 0.5, 0.0, 1.0);
    float ambientNightMul = mix(NIGHT_DARKNESS, 1.0, dayFactor);

    // Slightly higher base than world geometry (0.72 vs 0.68) so the held
    // item stays clearly legible in dim light.
    vec3 rawLightmap = texture2D(lightmap, lmcoord).rgb * 0.72;
    float torchStrength = clamp(lmcoord.x * 1.4, 0.0, 1.0);
    vec3 lightmapColor = rawLightmap * mix(ambientNightMul, 1.0, torchStrength);

    vec3 lit = albedo.rgb * max(clamp(lightmapColor, 0.0, 1.0), vec3(MIN_LIGHT));

    gl_FragColor = vec4(lit, albedo.a);
}
