#version 120
/*
 Vessel Shaders V14 — gbuffers_terrain.fsh
 Lights terrain using the vanilla lightmap + a directional sun/moon term,
 with soft PCF-filtered shadows and slope-scaled bias to fight both shadow
 acne and peter-panning, colored flat rendering for self-lit blocks (see
 isEmissive/emissiveTint below), and a custom exponential distance fog
 blended toward the sky/fog color.
 V14 additions:
 - MIN_LIGHT: a floor under the total light so nothing goes fully pure
   black (deep caves, unlit interiors), while leaving normally-lit areas
   untouched.
 - Procedural cloud shadows: dims the direct sun/moon term slightly under
   drifting noise-based "cloud" patches. Honest note — this does NOT read
   Minecraft's actual rendered cloud layer/texture (I don't have a
   confirmed way to access that from a shader), it's an approximation
   using Iris's built-in noise texture scrolled slowly over world
   position. Visually similar in spirit, not a literal cloud-shadow match.
*/

#define SHADOW_SOFTNESS 1.0 // [0.0 1.0 2.0 3.0] texel-radius of the soft-shadow blur
#define SHADOW_STRENGTH 0.55 // [0.2 0.35 0.55 0.7 0.85] how dark full shadow gets
#define SUN_STRENGTH 0.28 // [0.1 0.2 0.28 0.4 0.55] strength of direct sun/moon shading
#define FOG_DENSITY 0.0018 // [0.0008 0.0015 0.0018 0.0025 0.004 0.006] lowered in V15 - default fog was washing out mid-range scenery
#define NIGHT_DARKNESS 0.35 // [0.15 0.25 0.35 0.5 0.7] how much ambient/moon light remains at night (lower = darker nights)
#define EMISSIVE_BRIGHTNESS 0.9 // [0.7 0.8 0.9 1.0 1.1] flat brightness for self-lit blocks (glowstone, sea lantern, shroomlight, etc.)
#define EMISSIVE_TINT_STRENGTH 0.55 // [0.0 0.25 0.4 0.55 0.7 0.85] how strongly self-lit blocks pull toward their characteristic color
#define COLOR_BLEED_STRENGTH 0.5 // [0.0 0.25 0.5 0.75 1.0] approximate colored-light-bleed onto nearby lit surfaces (see header note)
#define MIN_LIGHT 0.05 // [0.0 0.03 0.05 0.08 0.12] floor so nothing goes fully pure black
#define CLOUD_SHADOW_STRENGTH 0.35 // [0.0 0.2 0.35 0.5 0.7] how much the sun dims under a "cloud" patch (see header note — procedural approximation)

uniform sampler2D gtexture;
uniform sampler2D lightmap;
uniform sampler2D shadowtex0;
uniform sampler2D noisetex;
uniform vec3 shadowLightPosition; // direction toward sun/moon, in eye space
uniform vec3 sunPosition;         // always points toward the sun (even below horizon)
uniform vec3 upPosition;          // "up" direction in eye space
uniform vec3 fogColor;
uniform float alphaTestRef;
uniform float frameTimeCounter;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertColor;
varying vec3 normal;
varying vec4 shadowPos;
varying float viewDist;
varying float isFoliage;
varying float isEmissive;
varying vec3 emissiveTint;
varying vec2 worldPosXZ;

// Must match shaders.properties' shadowMapResolution. If you change that
// value, update this constant too — I'm not relying on an assumed
// "shadowMapResolution" uniform since I can't verify its exact
// availability/name for this Iris/Minecraft combination without testing.
const float SHADOW_TEXEL = 1.0 / 1024.0;

// 4-tap PCF (percentage-closer filtering) — reduced from 9-tap in V1-V5 for
// performance, since this runs on nearly every opaque terrain fragment.
float sampleShadowPCF(vec4 sp, float NdotL) {
    if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0 || sp.z < 0.0 || sp.z > 1.0) {
        return 1.0; // outside shadow map coverage: assume lit
    }

    // Slope-scaled bias: fragments nearly edge-on to the light need a larger
    // bias to avoid acne; near-perpendicular fragments can use a tight one
    // to avoid peter-panning (shadow detaching from its caster).
    float bias = mix(0.0030, 0.0007, NdotL);

    float litSamples = 0.0;
    for (float x = -1.0; x <= 1.0; x += 2.0) {
        for (float y = -1.0; y <= 1.0; y += 2.0) {
            vec2 offset = vec2(x, y) * SHADOW_TEXEL * SHADOW_SOFTNESS * 0.75;
            float occluderDepth = texture2D(shadowtex0, sp.xy + offset).r;
            litSamples += (sp.z - bias > occluderDepth) ? 0.0 : 1.0;
        }
    }

    float litFraction = litSamples / 4.0;
    float minLight = clamp(1.0 - SHADOW_STRENGTH, 0.0, 1.0);
    return mix(minLight, 1.0, litFraction);
}

// Single-tap shadow test — much cheaper than the PCF version above. Used
// only for waving grass/leaves (see isFoliage), which are by far the
// highest fragment-count geometry in most worlds (every overlapping leaf
// quad in a forest), so this is where the biggest performance win is.
// Self-shadowing detail on foliage isn't very noticeable anyway, so the
// harder edge here is a good trade for the fragment-count savings.
float sampleShadowFast(vec4 sp) {
    if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0 || sp.z < 0.0 || sp.z > 1.0) {
        return 1.0;
    }
    float occluderDepth = texture2D(shadowtex0, sp.xy).r;
    float minLight = clamp(1.0 - SHADOW_STRENGTH, 0.0, 1.0);
    return (sp.z - 0.0015 > occluderDepth) ? minLight : 1.0;
}

// Procedural "cloud shadow" approximation: samples Iris's built-in noise
// texture at a slowly-drifting world-space UV to get a patchy coverage
// value, used to dim the direct sun/moon term a bit — NOT a read of
// Minecraft's actual cloud layer (see header note).
float cloudShadowAt(vec2 worldXZ, float time) {
    vec2 cloudUV = worldXZ * 0.0015 + vec2(time * 0.0015, time * 0.0009);
    float coverage = texture2D(noisetex, cloudUV).r;
    float shadowAmount = smoothstep(0.4, 0.6, coverage) * CLOUD_SHADOW_STRENGTH;
    return 1.0 - shadowAmount;
}

void main() {
    vec4 albedo = texture2D(gtexture, texcoord) * vertColor;
    if (albedo.a < alphaTestRef) discard;

    // Self-lit blocks (glowstone, sea lantern, torches, etc.): vanilla
    // renders these at a flat full brightness regardless of shading,
    // shadow, or time of day. This skips directional/shadow lighting
    // entirely — same treatment vanilla gives them — and blends the
    // result toward each block's characteristic color (emissiveTint) for
    // a more vividly "colored lighting" look. The blend uses the
    // texture's own luminance pattern (not a flat color fill), so texture
    // detail and shading variation on the block's own face are preserved.
    if (isEmissive > 0.5) {
        vec3 flatLit = albedo.rgb * EMISSIVE_BRIGHTNESS;
        float lum = dot(flatLit, vec3(0.299, 0.587, 0.114));
        vec3 tinted = lum * emissiveTint * 1.15;
        flatLit = mix(flatLit, tinted, EMISSIVE_TINT_STRENGTH);

        float fogFactor = clamp(1.0 - exp(-viewDist * FOG_DENSITY), 0.0, 1.0);
        vec3 finalColor = mix(flatLit, fogColor, fogFactor);
        gl_FragColor = vec4(finalColor, albedo.a);
        return;
    }

    vec3 n = normalize(normal);
    float NdotL = max(dot(n, normalize(shadowLightPosition)), 0.0);
    float shadow = (isFoliage > 0.5) ? sampleShadowFast(shadowPos) : sampleShadowPCF(shadowPos, NdotL);

    // How high the sun is above the horizon: ~1 at noon, ~0 at the horizon,
    // negative once it's set. Used to fade ambient/moon light down at
    // night rather than treating moonlight the same as sunlight.
    float sunHeight = dot(normalize(sunPosition), normalize(upPosition));
    float dayFactor = clamp(sunHeight * 3.0 + 0.5, 0.0, 1.0);
    float ambientNightMul = mix(NIGHT_DARKNESS, 1.0, dayFactor);

    // Vanilla lightmap: lmcoord.x is block/torch light, lmcoord.y is sky
    // light (standard Iris/OptiFine convention). Only the sky-lit portion
    // gets dimmed at night — torches should stay bright so you can still
    // see near light sources after dark.
    vec3 rawLightmap = texture2D(lightmap, lmcoord).rgb * 0.68;
    float torchStrength = clamp(lmcoord.x * 1.4, 0.0, 1.0);
    vec3 lightmapColor = rawLightmap * mix(ambientNightMul, 1.0, torchStrength);

    // Approximate colored light bleed: vanilla's own lightmap texture
    // already bakes in a warm tint for block light, but it's fairly
    // muted. This boosts that tint's saturation in proportion to how
    // torch-lit the fragment is, so surfaces near light sources read as
    // more vividly warm-colored. This is NOT true per-source colored
    // light (a sea lantern's blue and a torch's orange both get the same
    // treatment here, since vanilla's lightmap doesn't tell us which
    // specific block is the source) — real per-source colored light
    // propagation onto neighboring blocks isn't feasible in this shader
    // format without a much more complex deferred-lighting architecture.
    float lmLum = dot(lightmapColor, vec3(0.299, 0.587, 0.114));
    vec3 lmSaturated = mix(vec3(lmLum), lightmapColor, 1.0 + COLOR_BLEED_STRENGTH);
    lightmapColor = mix(lightmapColor, max(lmSaturated, vec3(0.0)), torchStrength);

    // Directional sun/moon term, gated by the (now soft) shadow map,
    // faded down at night, and modestly dimmed by the procedural cloud
    // shadow approximation. Combined total is hard-clamped to 1.0 so
    // nothing enters the tonemapper already overexposed.
    float cloudShadow = cloudShadowAt(worldPosXZ, frameTimeCounter);
    float directional = NdotL * shadow * SUN_STRENGTH * ambientNightMul * cloudShadow;
    vec3 totalLight = clamp(lightmapColor + vec3(directional), 0.0, 1.0);

    // Minimum lighting floor: guarantees a small amount of visibility even
    // in fully dark spots (unlit caves, sealed interiors) instead of going
    // to pure black. Doesn't affect anywhere already brighter than this.
    totalLight = max(totalLight, vec3(MIN_LIGHT));

    vec3 lit = albedo.rgb * totalLight;

    // Custom exponential fog toward the sky/fog color, based on view distance.
    float fogFactor = clamp(1.0 - exp(-viewDist * FOG_DENSITY), 0.0, 1.0);
    vec3 finalColor = mix(lit, fogColor, fogFactor);

    gl_FragColor = vec4(finalColor, albedo.a);
}
