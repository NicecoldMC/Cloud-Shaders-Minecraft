#version 120
/*
 Vessel Shaders V14 — gbuffers_entities.fsh
 Same PCF soft-shadow + slope-scaled-bias technique as gbuffers_terrain.fsh,
 applied to mobs/players so they visibly darken when standing in shadow.
 V14: added the same minimum-lighting floor as terrain (MIN_LIGHT), so
 mobs/players in fully dark spots aren't rendered pure black.
*/

#define SHADOW_SOFTNESS 1.0 // [0.0 1.0 2.0 3.0]
#define SHADOW_STRENGTH 0.55 // [0.2 0.35 0.55 0.7 0.85]
#define SUN_STRENGTH 0.28 // [0.1 0.2 0.28 0.4 0.55]
#define FOG_DENSITY 0.0018 // [0.0008 0.0015 0.0018 0.0025 0.004 0.006] lowered in V15 - default fog was washing out mid-range scenery
#define NIGHT_DARKNESS 0.35 // [0.15 0.25 0.35 0.5 0.7]
#define COLOR_BLEED_STRENGTH 0.5 // [0.0 0.25 0.5 0.75 1.0] approximate colored-light-bleed near torches etc. (see gbuffers_terrain.fsh)
#define MIN_LIGHT 0.05 // [0.0 0.03 0.05 0.08 0.12] floor so nothing goes fully pure black

uniform sampler2D gtexture;
uniform sampler2D lightmap;
uniform sampler2D shadowtex0;
uniform vec3 shadowLightPosition;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform vec3 fogColor;
uniform vec4 entityColor; // hit-flash tint (white, animated alpha) supplied by vanilla
uniform float alphaTestRef;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertColor;
varying vec3 normal;
varying vec4 shadowPos;
varying float viewDist;

const float SHADOW_TEXEL = 1.0 / 1024.0; // must match shaders.properties shadowMapResolution

float sampleShadow(vec4 sp, float NdotL) {
    if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0 || sp.z < 0.0 || sp.z > 1.0) {
        return 1.0;
    }
    float bias = mix(0.0030, 0.0007, NdotL);
    float litSamples = 0.0;
    for (float x = -1.0; x <= 1.0; x += 2.0) {
        for (float y = -1.0; y <= 1.0; y += 2.0) {
            vec2 offset = vec2(x, y) * SHADOW_TEXEL * SHADOW_SOFTNESS * 0.75;
            float occluderDepth = texture2D(shadowtex0, sp.xy + offset).r;
            litSamples += (sp.z - bias > occluderDepth) ? 0.0 : 1.0;
        }
    }
    float litFraction = litSamples / 4.0;
    float minLight = clamp(1.0 - SHADOW_STRENGTH, 0.0, 1.0);
    return mix(minLight, 1.0, litFraction);
}

void main() {
    vec4 albedo = texture2D(gtexture, texcoord) * vertColor;
    if (albedo.a < alphaTestRef) discard;

    vec3 n = normalize(normal);
    float NdotL = max(dot(n, normalize(shadowLightPosition)), 0.0);
    float shadow = sampleShadow(shadowPos, NdotL);

    float sunHeight = dot(normalize(sunPosition), normalize(upPosition));
    float dayFactor = clamp(sunHeight * 3.0 + 0.5, 0.0, 1.0);
    float ambientNightMul = mix(NIGHT_DARKNESS, 1.0, dayFactor);

    vec3 rawLightmap = texture2D(lightmap, lmcoord).rgb * 0.68;
    float torchStrength = clamp(lmcoord.x * 1.4, 0.0, 1.0);
    vec3 lightmapColor = rawLightmap * mix(ambientNightMul, 1.0, torchStrength);

    float lmLum = dot(lightmapColor, vec3(0.299, 0.587, 0.114));
    vec3 lmSaturated = mix(vec3(lmLum), lightmapColor, 1.0 + COLOR_BLEED_STRENGTH);
    lightmapColor = mix(lightmapColor, max(lmSaturated, vec3(0.0)), torchStrength);

    vec3 totalLight = clamp(lightmapColor + vec3(NdotL * shadow * SUN_STRENGTH * ambientNightMul), 0.0, 1.0);
    totalLight = max(totalLight, vec3(MIN_LIGHT));
    vec3 lit = albedo.rgb * totalLight;

    // Hit-flash overlay ("red effect" when you damage something). Previously
    // this mixed straight to the raw entityColor regardless of time of day,
    // which is why it stood out as too bright at night once everything
    // else got darkened. Now it dims along with the rest of the scene, with
    // a floor so it's still clearly visible as feedback rather than
    // vanishing into the dark.
    vec3 flashColor = entityColor.rgb * mix(0.55, 1.0, ambientNightMul);
    lit = mix(lit, flashColor, entityColor.a);

    float fogFactor = clamp(1.0 - exp(-viewDist * FOG_DENSITY), 0.0, 1.0);
    vec3 finalColor = mix(lit, fogColor, fogFactor);

    gl_FragColor = vec4(finalColor, albedo.a);
}
