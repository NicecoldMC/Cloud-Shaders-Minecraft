#version 120
/*
 Vessel Shaders V15 — final.fsh
 Last pass: contrast, saturation, a filmic tonemap curve (Hejl/Burgess-
 Dawson approximation), and a soft vignette. Writes directly to the screen,
 so no DRAWBUFFERS directive is needed here.
 V15: the pack had a saturation control but no real contrast control,
 which is likely why it could look flat/washed even with saturation
 turned up — correct hues but low separation between shadows and
 highlights reads as "milky" rather than punchy. Added a proper
 pivot-based contrast adjustment (CONTRAST), and pushed the saturation
 default up further (1.3 -> 1.45). EXPOSURE is unchanged — this is about
 color punch, not overall brightness.
*/
#define EXPOSURE 0.6 // [0.35 0.45 0.55 0.6 0.65 0.75 0.85]
#define CONTRAST 1.2 // [1.0 1.1 1.2 1.3 1.45] pivot-based contrast — higher spreads shadows/highlights further apart
#define SATURATION 1.45 // [1.0 1.15 1.3 1.45 1.6 1.75]
#define VIGNETTE_STRENGTH 0.6 // [0.0 0.3 0.6 0.9 1.2]

uniform sampler2D colortex0;
varying vec2 texcoord;

vec3 tonemapFilmic(vec3 c) {
    vec3 x = max(vec3(0.0), c - 0.004);
    return (x * (6.2 * x + 0.5)) / (x * (6.2 * x + 1.7) + 0.06);
}

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;

    color = tonemapFilmic(color * EXPOSURE);

    float luma = dot(color, vec3(0.2126, 0.7152, 0.0722));
    color = mix(vec3(luma), color, SATURATION);

    // Pivot-based contrast: spreads values away from mid-gray in both
    // directions (shadows darker, highlights brighter) without changing
    // the overall average brightness the way raising EXPOSURE would.
    color = clamp((color - 0.5) * CONTRAST + 0.5, 0.0, 1.0);

    // Genuine darkening curve: gamma > 1 pulls midtones/highlights down
    // without crushing shadows to black the way a flat multiply would.
    color = pow(clamp(color, 0.0, 1.0), vec3(1.25));

    vec2 uv = texcoord - 0.5;
    float vignette = 1.0 - dot(uv, uv) * VIGNETTE_STRENGTH;
    color *= vignette;

    gl_FragColor = vec4(color, 1.0);
}
