#version 120
/*
 Vessel Shaders — gbuffers_terrain.vsh
 Handles: all solid/cutout world terrain (blocks).
 Adds: waving grass & leaves, and computes shadow-space position for the
 fragment shader to sample the shadow map.
*/

#define WAVING_STRENGTH 0.8 // [0.0 0.4 0.8 1.2 1.6]

attribute vec4 mc_Entity;      // x = custom block ID from block.properties (-1 if unset)
attribute vec2 mc_midTexCoord; // center of this quad's texture, used to find the "top" vertex

uniform float frameTimeCounter;
uniform vec3 cameraPosition;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertColor;
varying vec3 normal;
varying vec4 shadowPos;
varying float viewDist;
varying float isFoliage; // 1.0 for waving grass/leaves, 0.0 otherwise — lets the
                          // fragment shader use a much cheaper shadow path on the
                          // highest-density geometry (see gbuffers_terrain.fsh)
varying float isEmissive; // 1.0 for self-lit blocks (glowstone, sea lantern,
                           // shroomlight, etc. — see block.properties block.10003-10010).
                           // Lets the fragment shader render these flat/full-bright
                           // like vanilla does, instead of shading them normally.
varying vec3 emissiveTint; // characteristic light color for the emissive block
                            // detected above (only meaningful when isEmissive > 0.5)
varying vec2 worldPosXZ; // for the procedural cloud-shadow noise sample in the .fsh

// Pulls shadow detail toward the player so nearby shadows stay sharp while
// distant ones compress into the fixed-resolution shadow map.
vec3 distortShadowClipPos(vec3 pos) {
    float factor = length(pos.xy) + 0.10;
    pos.xy /= factor;
    return pos;
}

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vertColor = gl_Color;
    normal = gl_NormalMatrix * gl_Normal;

    vec4 position = gl_Vertex;
    worldPosXZ = position.xz + cameraPosition.xz;
    int blockId = int(mc_Entity.x + 0.5);
    isFoliage = (blockId == 10001 || blockId == 10002) ? 1.0 : 0.0;
    isEmissive = (blockId >= 10003 && blockId <= 10010) ? 1.0 : 0.0;

    // Characteristic color per light type, so each glows its own hue
    // instead of one uniform brightness. Colors are an artistic match to
    // each block's real-world/vanilla appearance, not a measured value.
    emissiveTint = vec3(1.0);
    if (blockId == 10003) emissiveTint = vec3(1.00, 0.83, 0.50); // glowstone: warm yellow
    else if (blockId == 10004) emissiveTint = vec3(0.75, 0.95, 1.00); // sea lantern: pale cyan
    else if (blockId == 10005) emissiveTint = vec3(1.00, 0.62, 0.30); // torch/lantern/jack-o'-lantern/campfire: warm orange
    else if (blockId == 10006) emissiveTint = vec3(0.45, 0.80, 1.00); // soul torch/lantern/campfire: cyan-blue
    else if (blockId == 10007) emissiveTint = vec3(1.00, 0.55, 0.55); // shroomlight: pink-orange
    else if (blockId == 10008) emissiveTint = vec3(0.95, 0.92, 0.80); // redstone lamp/beacon/end rod: warm white
    else if (blockId == 10009) emissiveTint = vec3(0.75, 1.00, 0.45); // firefly bush: yellow-green
    else if (blockId == 10010) emissiveTint = vec3(1.00, 0.65, 0.30); // torchflower: warm orange (cosmetic only — see README)

    if (WAVING_STRENGTH > 0.0 && isFoliage > 0.5) {
        // Only the top vertex of the quad sways; the base stays anchored.
        // In Minecraft's texture space V increases downward, so the top
        // vertex has a smaller v than the quad's mid texcoord.
        float isTop = step(gl_MultiTexCoord0.y, mc_midTexCoord.y);

        vec3 worldPos = position.xyz + cameraPosition;
        float t = frameTimeCounter * 1.2;
        float phase = worldPos.x * 0.5 + worldPos.z * 0.5;

        float swayX = sin(t + phase) * 0.06 * WAVING_STRENGTH;
        float swayZ = cos(t * 0.8 + phase) * 0.06 * WAVING_STRENGTH;

        position.x += swayX * isTop;
        position.z += swayZ * isTop;
    }

    vec4 viewPos = gl_ModelViewMatrix * position;
    viewDist = length(viewPos.xyz);
    gl_Position = gl_ProjectionMatrix * viewPos;

    // Camera-relative "world" position (same convention Iris uses for the
    // shadow matrices), used to project into shadow-map space.
    vec4 worldSpacePos = gbufferModelViewInverse * viewPos;
    vec4 sPos = shadowProjection * (shadowModelView * worldSpacePos);
    sPos.xyz = distortShadowClipPos(sPos.xyz);
    // The shadow projection is orthographic (w == 1), so only xyz need the
    // [-1,1] -> [0,1] remap for texture/depth sampling; w is left untouched.
    shadowPos = vec4(sPos.xyz * 0.5 + 0.5, sPos.w);
}
