#version 120
/*
 Vessel Shaders V12 — gbuffers_textured.vsh
 Used for: particles (block-break dust, critical hits, etc.), and
 whatever else falls back to this generic textured pass. Sky/sun/moon and
 the hand item have their own dedicated programs (see gbuffers_skytextured,
 gbuffers_skybasic, gbuffers_hand), and GUI/HUD elements are drawn by Iris
 after the shader pipeline runs, so they're unaffected by this file.
 V12: now samples the lightmap and passes it through, so particles can be
 night-darkened the same way terrain/entities are (see .fsh) instead of
 always rendering at full raw brightness regardless of time of day.
*/
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertColor;
varying float viewDist;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vertColor = gl_Color;
    viewDist = length((gl_ModelViewMatrix * gl_Vertex).xyz);
}
