#version 120
/*
 Vessel Shaders V14 — gbuffers_water.fsh
 Per-fragment procedural wave normal (3 octaves, sampled at world position,
 not interpolated from the coarse mesh) drives lighting/glint. 4-tap PCF
 shadows for performance. Depth-based shallow/deep color and Schlick
 fresnel from V13, unchanged.
 V14: the sun-glint specular highlight now uses a proper GGX/Cook-Torrance
 term (normal distribution + Smith geometry function) instead of a plain
 pow(x, 120) curve — a physically-based specular model gives a more
 correctly-shaped highlight (tighter core, more natural falloff) than an
 arbitrary exponent. This is a standard, well-documented real-time
 rendering technique (used in countless PBR renderers/shaders), written
 fresh for this pack — not sourced from any specific shader pack.
*/

#define WATER_WAVE_STRENGTH 1.0 // [0.4 0.7 1.0 1.3 1.6]
#define WATER_ROUGHNESS 0.08 // [0.03 0.05 0.08 0.12 0.2] lower = tighter, more mirror-like sun glint
#define SHADOW_SOFTNESS 1.0 // [0.0 1.0 2.0 3.0]
#define SHADOW_STRENGTH 0.4 // [0.15 0.25 0.4 0.55 0.7]
#define FOG_DENSITY 0.0018 // [0.0008 0.0015 0.0018 0.0025 0.004 0.006] lowered in V15 - default fog was washing out mid-range scenery
#define NIGHT_DARKNESS 0.35 // [0.15 0.25 0.35 0.5 0.7]
#define WATER_DEPTH_FALLOFF 6.0 // [3.0 4.5 6.0 8.0 12.0] blocks of depth until water reaches full "deep" color/opacity
#define FOAM_STRENGTH 0.2 // [0.0 0.1 0.2 0.35 0.5] white foam at steep wave crests

uniform sampler2D gtexture;
uniform sampler2D lightmap;
uniform sampler2D shadowtex0;
uniform sampler2D depthtex1;
uniform mat4 gbufferProjectionInverse;
uniform vec3 fogColor;
uniform vec3 shadowLightPosition;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform float frameTimeCounter;
uniform float viewWidth;
uniform float viewHeight;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertColor;
varying vec3 viewDir;
varying vec3 worldPos;
varying vec4 shadowPos;
varying vec3 viewPosOut;
varying float viewDist;

const vec3 WATER_DEEP  = vec3(0.02, 0.10, 0.16); // deep/shadowed water tint
const vec3 WATER_SHALLOW = vec3(0.10, 0.32, 0.36); // sunlit surface tint
const vec3 WATER_SHALLOW_EDGE = vec3(0.55, 0.75, 0.72); // thin/shoreline water — much lighter, near-clear
const float SHADOW_TEXEL = 1.0 / 1024.0; // must match shaders.properties shadowMapResolution

// 4-tap PCF (was 9-tap in V1-V5) — a meaningful performance win since this
// runs on every visible water fragment, at the cost of very slightly
// coarser shadow edges on water specifically.
float sampleShadow(vec4 sp, float NdotL) {
    if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0 || sp.z < 0.0 || sp.z > 1.0) {
        return 1.0;
    }
    float bias = mix(0.0030, 0.0007, NdotL);
    float litSamples = 0.0;
    for (float x = -1.0; x <= 1.0; x += 2.0) {
        for (float y = -1.0; y <= 1.0; y += 2.0) {
            vec2 offset = vec2(x, y) * SHADOW_TEXEL * SHADOW_SOFTNESS * 0.75;
            float occluderDepth = texture2D(shadowtex0, sp.xy + offset).r;
            litSamples += (sp.z - bias > occluderDepth) ? 0.0 : 1.0;
        }
    }
    float litFraction = litSamples / 4.0;
    float minLight = clamp(1.0 - SHADOW_STRENGTH, 0.0, 1.0);
    return mix(minLight, 1.0, litFraction);
}

// Per-fragment procedural wave normal: three octaves of sine ripples at
// increasing frequency/decreasing amplitude, sampled at this exact pixel's
// world position rather than interpolated from the coarse mesh.
vec3 waveNormalAt(vec2 pos, float t) {
    float dHdx = 0.0;
    float dHdz = 0.0;

    dHdx += cos(pos.x * 0.6 + t * 1.1) * 0.6 * 0.035;
    dHdz += cos(pos.y * 0.4 - t * 0.8) * 0.4 * 0.035;

    dHdx += cos(pos.x * 1.7 + t * 1.8) * 1.7 * 0.012;
    dHdz += cos(pos.y * 1.3 - t * 1.4) * 1.3 * 0.012;

    dHdx += cos(pos.x * 3.8 + t * 2.6) * 3.8 * 0.004;
    dHdz += cos(pos.y * 3.1 - t * 2.1) * 3.1 * 0.004;

    dHdx *= WATER_WAVE_STRENGTH;
    dHdz *= WATER_WAVE_STRENGTH;

    return normalize(vec3(-dHdx, 1.0, -dHdz));
}

void main() {
    vec4 albedo = texture2D(gtexture, texcoord) * vertColor;

    vec3 n = waveNormalAt(worldPos.xz, frameTimeCounter);
    vec3 lightDir = normalize(shadowLightPosition);
    vec3 view = normalize(viewDir);

    float NdotL = max(dot(n, lightDir), 0.0);
    float shadow = sampleShadow(shadowPos, NdotL);

    // Schlick's approximation: real water reflects only ~2% of light at
    // normal incidence (looking straight down into it) but nearly 100% at
    // grazing angles (looking almost along the surface) — this is why
    // looking straight down into a lake looks clear/dark but looking
    // across it looks like a mirror. The old pow(x,4) curve had no
    // physical basis; this is the standard real-time water technique.
    float cosTheta = clamp(dot(n, view), 0.0, 1.0);
    const float F0 = 0.02;
    float fresnel = F0 + (1.0 - F0) * pow(1.0 - cosTheta, 5.0);

    float sunHeight = dot(normalize(sunPosition), normalize(upPosition));
    float dayFactor = clamp(sunHeight * 3.0 + 0.5, 0.0, 1.0);
    float ambientNightMul = mix(NIGHT_DARKNESS, 1.0, dayFactor);

    // GGX normal distribution function (Trowbridge-Reitz) + Smith geometry
    // term: the standard physically-based specular model. NdotH close to 1
    // (half-vector aligned with the normal) gives the tight highlight core;
    // roughness controls how quickly it falls off away from that.
    vec3 halfVec = normalize(lightDir + view);
    float NdotH = max(dot(n, halfVec), 0.0);
    float NdotV = max(dot(n, view), 0.0001);
    float alpha2 = WATER_ROUGHNESS * WATER_ROUGHNESS * WATER_ROUGHNESS * WATER_ROUGHNESS;
    float dDenom = (NdotH * NdotH) * (alpha2 - 1.0) + 1.0;
    float D = alpha2 / max(3.14159265 * dDenom * dDenom, 1e-6);

    float k = (WATER_ROUGHNESS + 1.0);
    k = (k * k) * 0.125; // Schlick-GGX k for direct/analytic lights
    float Gv = NdotV / (NdotV * (1.0 - k) + k);
    float Gl = NdotL / (NdotL * (1.0 - k) + k);
    float G = Gv * Gl;

    float specular = (D * G) / max(4.0 * NdotV * NdotL, 0.001);
    float glint = clamp(specular * fresnel, 0.0, 4.0) * 0.5 * shadow * ambientNightMul;

    vec3 lightmapColor = texture2D(lightmap, lmcoord).rgb * 0.68 * ambientNightMul;

    // Water column depth: compare this surface's view-space position to
    // whatever opaque surface (lakebed, or the far plane if none) sits
    // behind it, from depthtex1 (depth excluding translucents like this
    // water itself). One texture sample + a matrix multiply — cheap.
    vec2 screenUV = gl_FragCoord.xy / vec2(viewWidth, viewHeight);
    float floorDepth = texture2D(depthtex1, screenUV).r;
    vec4 floorClip = vec4(screenUV * 2.0 - 1.0, floorDepth * 2.0 - 1.0, 1.0);
    vec4 floorViewPos4 = gbufferProjectionInverse * floorClip;
    vec3 floorViewPos = floorViewPos4.xyz / floorViewPos4.w;
    float waterColumnDepth = clamp(length(floorViewPos - viewPosOut), 0.0, 64.0);
    float depthFactor = clamp(waterColumnDepth / WATER_DEPTH_FALLOFF, 0.0, 1.0);

    vec3 waterColor = mix(WATER_DEEP, WATER_SHALLOW, NdotL * shadow);
    vec3 depthTintedColor = mix(WATER_SHALLOW_EDGE, waterColor, depthFactor);
    vec3 baseColor = mix(albedo.rgb, depthTintedColor, 0.65) * lightmapColor;

    vec3 litColor = baseColor + vec3(glint) * lightmapColor;
    litColor = mix(litColor, litColor + vec3(0.3, 0.33, 0.33), fresnel * 0.15);

    // Cheap foam hint: steep wave slopes (low n.y) get a touch of white,
    // reusing the wave normal we already computed — no extra trig calls.
    float slope = 1.0 - clamp(n.y, 0.0, 1.0);
    float foam = smoothstep(0.35, 0.6, slope) * FOAM_STRENGTH;
    litColor += vec3(foam);
    litColor = clamp(litColor, 0.0, 1.0);

    // Shallow water is much more see-through; deep water is more opaque.
    float alpha = clamp(albedo.a * mix(0.35, 1.0, depthFactor) + fresnel * 0.25 + glint * 0.3, 0.0, 1.0);

    float fogFactor = clamp(1.0 - exp(-viewDist * FOG_DENSITY), 0.0, 1.0);
    vec3 finalColor = mix(litColor, fogColor, fogFactor);

    gl_FragColor = vec4(finalColor, alpha);
}
