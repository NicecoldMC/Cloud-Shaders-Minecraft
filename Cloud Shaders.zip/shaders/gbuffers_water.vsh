#version 120
/*
 Vessel Shaders V13 — gbuffers_water.vsh
 Still displaces the coarse mesh for large-scale swell (cheap, done once per
 vertex — Minecraft water is only 4 vertices per block face, so this alone
 can't produce fine ripple detail). The actual shading normal used for
 lighting/glint is computed per-fragment in the .fsh from world position.
 V13: also passes the raw view-space position through, so the fragment
 shader can compare it against the lakebed depth for a depth-based
 shallow/deep water effect (see gbuffers_water.fsh) — one extra varying,
 no added per-fragment cost here.
*/

uniform float frameTimeCounter;
uniform vec3 cameraPosition;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertColor;
varying vec3 viewDir;
varying vec3 worldPos;
varying vec4 shadowPos;
varying vec3 viewPosOut;
varying float viewDist;

const float WAVE_A_FREQ = 0.6;
const float WAVE_A_SPEED = 1.1;
const float WAVE_A_AMP = 0.035;

const float WAVE_B_FREQ = 0.4;
const float WAVE_B_SPEED = 0.8;
const float WAVE_B_AMP = 0.035;

vec3 distortShadowClipPos(vec3 pos) {
    float factor = length(pos.xy) + 0.10;
    pos.xy /= factor;
    return pos;
}

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vertColor = gl_Color;

    vec4 position = gl_Vertex;
    worldPos = position.xyz + cameraPosition;
    float t = frameTimeCounter;

    float wave = sin(worldPos.x * WAVE_A_FREQ + t * WAVE_A_SPEED) * WAVE_A_AMP
               + sin(worldPos.z * WAVE_B_FREQ - t * WAVE_B_SPEED) * WAVE_B_AMP;
    position.y += wave;

    vec4 viewPos = gl_ModelViewMatrix * position;
    viewDir = normalize(-viewPos.xyz);
    viewDist = length(viewPos.xyz);
    viewPosOut = viewPos.xyz;

    gl_Position = gl_ProjectionMatrix * viewPos;

    vec4 worldSpacePos = gbufferModelViewInverse * viewPos;
    vec4 sPos = shadowProjection * (shadowModelView * worldSpacePos);
    sPos.xyz = distortShadowClipPos(sPos.xyz);
    shadowPos = vec4(sPos.xyz * 0.5 + 0.5, sPos.w);
}
